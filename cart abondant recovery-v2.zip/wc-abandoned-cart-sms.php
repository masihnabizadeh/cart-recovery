<?php
/*
Plugin Name: WooCommerce Abandoned Cart SMS
Description: Sends SMS reminders with coupon codes for abandoned carts.
Version: 1.0
Author: Masih Nabizadeh
*/

if (!defined('ABSPATH')) {
    exit;
}

define('WC_ACART_SMS_PATH', plugin_dir_path(__FILE__));
define('WC_ACART_SMS_URL', plugin_dir_url(__FILE__));

require_once WC_ACART_SMS_PATH . 'includes/class-database.php';
require_once WC_ACART_SMS_PATH . 'includes/class-cart-tracker.php';
require_once WC_ACART_SMS_PATH . 'includes/class-abandon-detector.php';
require_once WC_ACART_SMS_PATH . 'includes/class-coupon.php';
require_once WC_ACART_SMS_PATH . 'includes/class-sms.php';
require_once WC_ACART_SMS_PATH . 'includes/class-recovery.php';
require_once WC_ACART_SMS_PATH . 'includes/class-cron.php';

require_once WC_ACART_SMS_PATH . 'admin/class-admin-menu.php';
require_once WC_ACART_SMS_PATH . 'admin/class-admin-page.php';

class WC_Abandoned_Cart_SMS {

    public function __construct() {

        new WC_ACART_SMS_Database();
        new WC_ACART_SMS_Cart_Tracker();
        new WC_ACART_SMS_Abandon_Detector();
        new WC_ACART_SMS_Coupon();
        new WC_ACART_SMS_SMS();
        new WC_ACART_SMS_Recovery();
        new WC_ACART_SMS_Cron();

        if (is_admin()) {
            new WC_ACART_SMS_Admin_Menu();
            new WC_ACART_SMS_Admin_Page();
        }
    }
}

function wc_acart_sms_init() {
    new WC_Abandoned_Cart_SMS();
}
add_action('plugins_loaded', 'wc_acart_sms_init');

register_activation_hook(__FILE__, function () {
    WC_ACART_SMS_Database::create_table();
    WC_ACART_SMS_Cron::schedule();
});

register_deactivation_hook(__FILE__, function () {
    WC_ACART_SMS_Cron::unschedule();
});
