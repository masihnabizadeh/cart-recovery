<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Admin_Page {

    public static function render() {

        global $wpdb;
        $table = $wpdb->prefix . 'acart_sms_carts';

        $total_abandoned = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status='abandoned'");
        $sms_sent = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE sms_sent=1");
        $recovered = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE recovered=1");
        $revenue = $wpdb->get_var("SELECT SUM(cart_total) FROM $table WHERE recovered=1");

        $carts = $wpdb->get_results("SELECT * FROM $table ORDER BY created_at DESC LIMIT 50");
        ?>

        <div class="wrap">
            <h1>Abandoned Cart SMS</h1>

            <h2>گزارش ساده</h2>

            <ul>
                <li>تعداد سبد رها شده: <?php echo esc_html($total_abandoned); ?></li>
                <li>پیامک ارسال شده: <?php echo esc_html($sms_sent); ?></li>
                <li>بازیابی شده: <?php echo esc_html($recovered); ?></li>
                <li>درآمد بازیابی شده: <?php echo wc_price($revenue); ?></li>
            </ul>

            <h2>لیست سبدهای رها شده</h2>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Phone</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Coupon</th>
                        <th>Created</th>
                    </tr>
                </thead>
                <tbody>

                <?php foreach ($carts as $cart): ?>

                    <tr>
                        <td><?php echo esc_html($cart->id); ?></td>
                        <td><?php echo esc_html($cart->phone); ?></td>
                        <td><?php echo wc_price($cart->cart_total); ?></td>
                        <td><?php echo esc_html($cart->status); ?></td>
                        <td><?php echo esc_html($cart->coupon_code); ?></td>
                        <td><?php echo esc_html($cart->created_at); ?></td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>

        </div>

        <?php
    }
}
