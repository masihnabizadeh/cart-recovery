<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Admin_Menu {

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
    }

    public function register_menu() {

        add_submenu_page(
            'woocommerce',
            'Abandoned Cart SMS',
            'Abandoned Cart SMS',
            'manage_woocommerce',
            'wc-acart-sms',
            ['WC_ACART_SMS_Admin_Page', 'render']
        );
    }
}
