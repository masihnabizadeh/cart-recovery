/**
 * WooCommerce Abandoned Cart SMS - Admin Scripts
 */

(function($) {
    'use strict';
    
    $(document).ready(function() {
        
        // Initialize admin functionality
        WC_ACART_SMS_Admin.init();
        
    });
    
    var WC_ACART_SMS_Admin = {
        
        /**
         * Initialize
         */
        init: function() {
            this.bindEvents();
            this.initTooltips();
            this.validateForm();
        },
        
        /**
         * Bind events
         */
        bindEvents: function() {
            var self = this;
            
            // Confirm before running cron manually
            $('input[name="wc_acart_sms_run_cron"]').on('click', function(e) {
                if (!confirm('آیا مطمئن هستید که می‌خواهید Cron Job را به صورت دستی اجرا کنید؟')) {
                    e.preventDefault();
                }
            });
            
            // Real-time SMS template preview
            $('#sms_template').on('input', function() {
                self.updateSMSPreview($(this).val());
            });
            
            // Coupon type change
            $('#coupon_type').on('change', function() {
                self.updateCouponAmountLabel($(this).val());
            });
            
            // Auto-save settings (optional)
            $('.wc-acart-sms-settings input, .wc-acart-sms-settings select, .wc-acart-sms-settings textarea').on('change', function() {
                self.showSaveReminder();
            });
        },
        
        /**
         * Initialize tooltips
         */
        initTooltips: function() {
            // Add tooltips to stat boxes
            $('.stat-box').each(function() {
                $(this).attr('title', 'کلیک کنید برای جزئیات بیشتر');
            });
        },
        
        /**
         * Validate form before submit
         */
        validateForm: function() {
            $('form').on('submit', function(e) {
                var apiKey = $('#sms_api_key').val();
                var lineNumber = $('#sms_line_number').val();
                
                if (!apiKey || !lineNumber) {
                    if (!confirm('کلید API یا شماره خط پر نشده است. آیا می‌خواهید ادامه دهید؟')) {
                        e.preventDefault();
                        return false;
                    }
                }
                
                // Show loading
                $('input[type="submit"]').prop('disabled', true).after('<span class="wc-acart-sms-loading"></span>');
            });
        },
        
        /**
         * Update SMS preview
         */
        updateSMSPreview: function(template) {
            var preview = template
                .replace(/{site_name}/g, 'فروشگاه شما')
                .replace(/{coupon}/g, 'CART12345678')
                .replace(/{discount}/g, '10%')
                .replace(/{expiry}/g, '1404/03/15')
                .replace(/{cart_link}/g, 'https://example.com/cart');
            
            // Show preview (if preview element exists)
            if ($('#sms_preview').length) {
                $('#sms_preview').text(preview);
            }
        },
        
        /**
         * Update coupon amount label based on type
         */
        updateCouponAmountLabel: function(type) {
            var label = type === 'percent' ? 'درصد تخفیف' : 'مبلغ تخفیف (تومان)';
            $('label[for="coupon_amount"]').text(label);
        },
        
        /**
         * Show save reminder
         */
        showSaveReminder: function() {
            if (!$('.save-reminder').length) {
                $('.wc-acart-sms-settings h2').after(
                    '<div class="notice notice-warning save-reminder" style="margin: 15px 0;">' +
                    '<p>⚠️ تغییرات ذخیره نشده‌اند. فراموش نکنید دکمه "ذخیره تنظیمات" را بزنید.</p>' +
                    '</div>'
                );
            }
        },
        
        /**
         * AJAX: Delete cart
         */
        deleteCart: function(cartId) {
            if (!confirm('آیا مطمئن هستید که می‌خواهید این سبد را حذف کنید؟')) {
                return;
            }
            
            $.ajax({
                url: wcAcartSms.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wc_acart_sms_delete_cart',
                    nonce: wcAcartSms.nonce,
                    cart_id: cartId
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('خطا در حذف سبد خرید');
                    }
                }
            });
        },
        
        /**
         * AJAX: Resend SMS
         */
        resendSMS: function(cartId) {
            if (!confirm('آیا می‌خواهید پیامک را دوباره ارسال کنید؟')) {
                return;
            }
            
            $.ajax({
                url: wcAcartSms.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'wc_acart_sms_resend',
                    nonce: wcAcartSms.nonce,
                    cart_id: cartId
                },
                beforeSend: function() {
                    $('.resend-btn-' + cartId).prop('disabled', true).text('در حال ارسال...');
                },
                success: function(response) {
                    if (response.success) {
                        alert('پیامک با موفقیت ارسال شد');
                        location.reload();
                    } else {
                        alert('خطا در ارسال پیامک: ' + response.data.message);
                        $('.resend-btn-' + cartId).prop('disabled', false).text('ارسال مجدد');
                    }
                }
            });
        }
        
    };
    
    // Make functions globally accessible
    window.WC_ACART_SMS_Admin = WC_ACART_SMS_Admin;
    
})(jQuery);
