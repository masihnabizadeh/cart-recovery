<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Cron {

    public function __construct() {
        add_filter('cron_schedules', [$this, 'add_schedule']);
    }

    public function add_schedule($schedules) {

        $schedules['wc_acart_sms_5min'] = [
            'interval' => 300,
            'display'  => 'Every 5 Minutes'
        ];

        return $schedules;
    }

    public static function schedule() {

        if (!wp_next_scheduled('wc_acart_sms_cron')) {
            wp_schedule_event(time(), 'wc_acart_sms_5min', 'wc_acart_sms_cron');
        }
    }

    public static function unschedule() {

        $timestamp = wp_next_scheduled('wc_acart_sms_cron');

        if ($timestamp) {
            wp_unschedule_event($timestamp, 'wc_acart_sms_cron');
        }
    }
}
