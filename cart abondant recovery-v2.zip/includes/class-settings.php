<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Settings {

    public function __construct() {

        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);

    }

    public function add_menu() {

        add_submenu_page(
            'woocommerce',
            'Abandoned Cart SMS',
            'Abandoned Cart SMS',
            'manage_woocommerce',
            'wc-acart-sms',
            [$this, 'settings_page']
        );

    }

    public function register_settings() {

        register_setting('wc_acart_sms_group', 'wc_acart_sms_api_key');
        register_setting('wc_acart_sms_group', 'wc_acart_sms_line_number');

        register_setting('wc_acart_sms_group', 'wc_acart_sms_coupon_amount');
        register_setting('wc_acart_sms_group', 'wc_acart_sms_coupon_type');
        register_setting('wc_acart_sms_group', 'wc_acart_sms_coupon_expiry');
        register_setting('wc_acart_sms_group', 'wc_acart_sms_coupon_prefix');

    }

    public function settings_page() {
        ?>
        <div class="wrap">
            <h1>Abandoned Cart SMS Settings</h1>

            <form method="post" action="options.php">
                <?php settings_fields('wc_acart_sms_group'); ?>
                <?php do_settings_sections('wc_acart_sms_group'); ?>

                <table class="form-table">

                    <tr>
                        <th>SMS.ir API Key</th>
                        <td>
                            <input type="text" name="wc_acart_sms_api_key"
                                   value="<?php echo esc_attr(get_option('wc_acart_sms_api_key')); ?>"
                                   class="regular-text">
                        </td>
                    </tr>

                    <tr>
                        <th>Line Number</th>
                        <td>
                            <input type="text" name="wc_acart_sms_line_number"
                                   value="<?php echo esc_attr(get_option('wc_acart_sms_line_number')); ?>"
                                   class="regular-text">
                        </td>
                    </tr>

                    <tr>
                        <th>Coupon Type</th>
                        <td>
                            <select name="wc_acart_sms_coupon_type">
                                <option value="percent" <?php selected(get_option('wc_acart_sms_coupon_type'), 'percent'); ?>>
                                    Percentage
                                </option>
                                <option value="fixed_cart" <?php selected(get_option('wc_acart_sms_coupon_type'), 'fixed_cart'); ?>>
                                    Fixed Cart
                                </option>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th>Coupon Amount</th>
                        <td>
                            <input type="number" name="wc_acart_sms_coupon_amount"
                                   value="<?php echo esc_attr(get_option('wc_acart_sms_coupon_amount', 10)); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Coupon Expiry (hours)</th>
                        <td>
                            <input type="number" name="wc_acart_sms_coupon_expiry"
                                   value="<?php echo esc_attr(get_option('wc_acart_sms_coupon_expiry', 24)); ?>">
                        </td>
                    </tr>

                    <tr>
                        <th>Coupon Prefix</th>
                        <td>
                            <input type="text" name="wc_acart_sms_coupon_prefix"
                                   value="<?php echo esc_attr(get_option('wc_acart_sms_coupon_prefix', 'ACART')); ?>">
                        </td>
                    </tr>

                </table>

                <?php submit_button(); ?>

            </form>
        </div>
        <?php
    }

}

new WC_ACART_SMS_Settings();
