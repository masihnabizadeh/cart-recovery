<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Coupon {

    public static function generate($cart_id) {

        $code = 'ACART-' . strtoupper(wp_generate_password(6, false));

        $amount = 10; // درصد تخفیف
        $expiry_hours = 24;

        $coupon = [
            'post_title'   => $code,
            'post_content' => 'Abandoned Cart Discount',
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'shop_coupon'
        ];

        $coupon_id = wp_insert_post($coupon);

        update_post_meta($coupon_id, 'discount_type', 'percent');
        update_post_meta($coupon_id, 'coupon_amount', $amount);
        update_post_meta($coupon_id, 'individual_use', 'yes');
        update_post_meta($coupon_id, 'usage_limit', 1);

        $expiry_date = date('Y-m-d', strtotime("+$expiry_hours hours"));
        update_post_meta($coupon_id, 'date_expires', strtotime($expiry_date));

        global $wpdb;
        $table = $wpdb->prefix . 'acart_sms_carts';

        $wpdb->update(
            $table,
            [
                'coupon_code' => $code
            ],
            ['id' => $cart_id]
        );

        return $code;
    }
}
