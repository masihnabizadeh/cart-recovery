<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Abandon_Detector {

    const ABANDON_TIMEOUT = 45; // minutes

    public function __construct() {
        add_action('wc_acart_sms_cron', [$this, 'detect_abandoned']);
    }

    public function detect_abandoned() {

        global $wpdb;

        $table = $wpdb->prefix . 'acart_sms_carts';

        $time_limit = date('Y-m-d H:i:s', strtotime('-' . self::ABANDON_TIMEOUT . ' minutes'));

        $carts = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE status = 'active' AND phone IS NOT NULL AND updated_at < %s",
            $time_limit
        ));

        if (!$carts) {
            return;
        }

        foreach ($carts as $cart) {

            $coupon = WC_ACART_SMS_Coupon::generate($cart->id);
            $recovery_link = WC_ACART_SMS_Recovery::generate_link($cart->recovery_key);
            WC_ACART_SMS_SMS::send(
                $cart->phone,
                "سبد خرید شما هنوز تکمیل نشده! برای تکمیل خرید از این لینک استفاده کنید: $recovery_link. کد تخفیف شما: $coupon"
            );

            $wpdb->update(
                $table,
                [
                    'status' => 'abandoned',
                    'sms_sent' => 1,
                    'updated_at' => current_time('mysql')
                ],
                ['id' => $cart->id]
            );
        }
    }
}
