<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_SMS {

    public static function send($phone, $message) {

        $api_key = get_option('wc_acart_sms_api_key');
        $line_number = get_option('wc_acart_sms_line_number');

        if (empty($api_key) || empty($line_number) || empty($phone)) {
            return false;
        }

        $phone = self::normalize_phone($phone);

        $body = [
            'lineNumber' => $line_number,
            'messageText' => $message,
            'mobiles' => [$phone]
        ];

        $response = wp_remote_post('https://api.sms.ir/v1/send/bulk', [
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept'       => 'application/json',
                'x-api-key'    => $api_key
            ],
            'body' => json_encode($body),
            'timeout' => 20
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);

        return ($code == 200);
    }

    private static function normalize_phone($phone) {

        $phone = preg_replace('/[^0-9]/', '', $phone);

        if (strpos($phone, '09') === 0) {
            $phone = '98' . substr($phone, 1);
        }

        return $phone;
    }
}
