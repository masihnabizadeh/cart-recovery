<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Cart_Tracker {

    public function __construct() {
        add_action('woocommerce_cart_updated', [$this, 'track_cart']);
        add_action('woocommerce_checkout_update_order_review', [$this, 'track_cart']);
    }

    public function track_cart() {

        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        if (WC()->cart->is_empty()) {
            return;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'acart_sms_carts';

        $user_id = get_current_user_id();
        $session_id = WC()->session->get_customer_id();

        $cart_data = WC()->cart->get_cart();
        $cart_total = WC()->cart->get_total('edit');

        $phone = $this->extract_phone();

        $data = [
            'user_id' => $user_id ? $user_id : null,
            'session_id' => $session_id,
            'phone' => $phone,
            'cart' => maybe_serialize($cart_data),
            'cart_total' => $cart_total,
            'updated_at' => current_time('mysql')
        ];

        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $table WHERE session_id = %s AND status = 'active'",
            $session_id
        ));

        if ($existing) {

            $wpdb->update(
                $table,
                $data,
                ['id' => $existing->id]
            );

        } else {

            $data['created_at'] = current_time('mysql');

            $wpdb->insert($table, $data);
        }
    }

    private function extract_phone() {

        if (!empty($_POST['billing_phone'])) {
            return sanitize_text_field($_POST['billing_phone']);
        }

        if (is_user_logged_in()) {
            return get_user_meta(get_current_user_id(), 'billing_phone', true);
        }

        return null;
    }
}
