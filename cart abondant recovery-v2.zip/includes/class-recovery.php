<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Recovery {

    public function __construct() {
        add_action('init', [$this, 'handle_recovery']);
    }

    public static function generate_link($recovery_key) {
        return add_query_arg('acart_recover', $recovery_key, home_url('/'));
    }

    public function handle_recovery() {

        if (empty($_GET['acart_recover'])) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'acart_sms_carts';

        $recovery_key = sanitize_text_field($_GET['acart_recover']);

        $cart = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE recovery_key = %s",
            $recovery_key
        ));

        if (!$cart) {
            return;
        }

        $cart_items = maybe_unserialize($cart->cart);

        if (!WC()->cart) {
            return;
        }

        WC()->cart->empty_cart();

        foreach ($cart_items as $item) {
            if (!empty($item['product_id'])) {
                WC()->cart->add_to_cart(
                    $item['product_id'],
                    $item['quantity'],
                    isset($item['variation_id']) ? $item['variation_id'] : 0,
                    isset($item['variation']) ? $item['variation'] : []
                );
            }
        }

        if (!empty($cart->coupon_code)) {
            WC()->cart->apply_coupon($cart->coupon_code);
        }

        $wpdb->update(
            $table,
            [
                'status' => 'recovered',
                'recovered' => 1,
                'updated_at' => current_time('mysql')
            ],
            ['id' => $cart->id]
        );

        wp_safe_redirect(wc_get_cart_url());
        exit;
    }
}
