<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_ACART_SMS_Database {

    public static function create_table() {

        global $wpdb;

        $table = $wpdb->prefix . 'acart_sms_carts';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NULL,
            session_id VARCHAR(100) NULL,
            phone VARCHAR(20) NULL,
            cart LONGTEXT NOT NULL,
            cart_total DECIMAL(10,2) DEFAULT 0,
            status VARCHAR(20) DEFAULT 'active',
            coupon_code VARCHAR(50) NULL,
            recovery_key VARCHAR(64) NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            sms_sent TINYINT(1) DEFAULT 0,
            recovered TINYINT(1) DEFAULT 0,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY session_id (session_id),
            KEY phone (phone),
            KEY status (status)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

}
