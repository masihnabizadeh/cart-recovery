<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class WC_Acart_SMS_Cart_Tracker
 * 
 * بازنویسی شده: حذف کامل تمامی کدهای AJAX، JS و هوک‌های مرتبط با Checkout.
 * این کلاس اکنون فاقد هرگونه منطق اجرایی برای ردیابی سبد در Checkout است.
 */

class WC_Acart_SMS_Cart_Tracker {

    public function __construct() {
        // تمامی hookهای مربوط به wp_ajax، wp_footer و checkout حذف شدند.
    }

    /**
     * ثبت شماره موبایل (به جای AJAX قدیمی)
     * در صورت نیاز به استفاده از فرم‌های غیر Checkout، این متد فراخوانی می‌شود.
     */
    public static function log_customer_phone($order_id, $phone) {
        if (empty($order_id) || empty($phone)) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wc_acart_sms';

        $wpdb->update(
            $table,
            ['phone' => sanitize_text_field($phone)],
            ['order_id' => intval($order_id)],
            ['%s'],
            ['%d']
        );
    }
}
