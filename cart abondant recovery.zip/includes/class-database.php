<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Database {

    private static $table;

    public static function init() {
        global $wpdb;
        self::$table = $wpdb->prefix . 'wc_acart_sms';
    }

    public static function create_table() {

        global $wpdb;

        self::init();

        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE " . self::$table . " (

            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

            order_id BIGINT UNSIGNED NULL,
            phone VARCHAR(20) NOT NULL,

            recovery_key VARCHAR(64) NULL,

            sms_sent TINYINT(1) DEFAULT 0,
            recovered TINYINT(1) DEFAULT 0,

            recovered_order_id BIGINT UNSIGNED NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            PRIMARY KEY (id),
            KEY phone (phone),
            KEY recovery_key (recovery_key),
            KEY sms_sent (sms_sent),
            KEY recovered (recovered)

        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta($sql);
    }

    public static function insert_abandoned_cart($order_id, $phone, $recovery_key) {

        global $wpdb;

        self::init();

        $wpdb->insert(
            self::$table,
            [
                'order_id' => $order_id,
                'phone' => $phone,
                'recovery_key' => $recovery_key,
                'sms_sent' => 0,
                'recovered' => 0
            ],
            [
                '%d',
                '%s',
                '%s',
                '%d',
                '%d'
            ]
        );
    }

    public static function mark_sms_sent($id) {

        global $wpdb;

        self::init();

        $wpdb->update(
            self::$table,
            ['sms_sent' => 1],
            ['id' => $id],
            ['%d'],
            ['%d']
        );
    }

    public static function mark_recovered($recovery_key, $order_id) {

        global $wpdb;

        self::init();

        $wpdb->update(
            self::$table,
            [
                'recovered' => 1,
                'recovered_order_id' => $order_id
            ],
            ['recovery_key' => $recovery_key],
            ['%d','%d'],
            ['%s']
        );
    }

    public static function get_pending_sms() {

        global $wpdb;

        self::init();

        return $wpdb->get_results(
            "SELECT * FROM " . self::$table . "
            WHERE sms_sent = 0
            AND recovered = 0"
        );
    }

    public static function get_abandoned_carts() {

        global $wpdb;

        self::init();

        return $wpdb->get_results(
            "SELECT * FROM " . self::$table . "
            ORDER BY created_at DESC
            LIMIT 100"
        );
    }

    public static function get_sms_sent_count() {

        global $wpdb;

        self::init();

        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . self::$table . "
            WHERE sms_sent = 1"
        );
    }

    public static function get_recovered_carts_count() {

        global $wpdb;

        self::init();

        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM " . self::$table . "
            WHERE recovered = 1"
        );
    }

    public static function get_recovered_revenue() {

        global $wpdb;

        self::init();

        $orders = $wpdb->get_col(
            "SELECT recovered_order_id FROM " . self::$table . "
            WHERE recovered = 1
            AND recovered_order_id IS NOT NULL"
        );

        $total = 0;

        if ($orders) {

            foreach ($orders as $order_id) {

                $order = wc_get_order($order_id);

                if ($order) {
                    $total += $order->get_total();
                }

            }

        }

        return $total;
    }

}
