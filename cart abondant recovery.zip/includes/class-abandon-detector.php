<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Abandon_Detector {

    /**
     * Returns carts/orders that should be treated as abandoned.
     *
     * Logic:
     * - find carts older than configured timeout
     * - exclude recovered rows
     * - exclude carts that already have a recent corresponding order
     */
    public function get_candidates() {
        global $wpdb;

        $timeout_minutes = absint(get_option('wc_acart_sms_abandon_time', 45));
        if ($timeout_minutes < 1) {
            $timeout_minutes = 45;
        }

        $threshold = date('Y-m-d H:i:s', strtotime("-{$timeout_minutes} minutes"));

        $table = self::get_table_name();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE last_activity <= %s
                   AND abandoned_at IS NULL
                   AND recovered = 0
                 ORDER BY last_activity ASC",
                $threshold
            )
        );

        if (empty($rows)) {
            return [];
        }

        $candidates = [];

        foreach ($rows as $row) {
            if ($this->has_recent_order($row)) {
                $this->mark_as_processed($row->id);
                continue;
            }

            $candidates[] = $row;
        }

        return $candidates;
    }

    /**
     * Check if there is a real order after the last activity time
     * for the same customer/phone.
     */
    private function has_recent_order($cart_row) {
        if (empty($cart_row)) {
            return false;
        }

        $last_activity = !empty($cart_row->last_activity)
            ? $cart_row->last_activity
            : current_time('mysql');

        $args = [
            'limit'        => 1,
            'return'       => 'ids',
            'status'       => array_keys(wc_get_order_statuses()),
            'orderby'      => 'date',
            'order'        => 'DESC',
            'date_created' => '>' . strtotime($last_activity),
        ];

        if (!empty($cart_row->user_id) && absint($cart_row->user_id) > 0) {
            $args['customer_id'] = absint($cart_row->user_id);
        }

        $orders = wc_get_orders($args);

        if (!empty($orders)) {
            return true;
        }

        // Guest fallback: match billing phone if available
        if (!empty($cart_row->phone)) {
            $orders = wc_get_orders([
                'limit'   => 1,
                'return'  => 'ids',
                'status'  => array_keys(wc_get_order_statuses()),
                'orderby' => 'date',
                'order'   => 'DESC',
                'meta_query' => [
                    [
                        'key'     => '_billing_phone',
                        'value'   => $cart_row->phone,
                        'compare' => '=',
                    ],
                ],
                'date_created' => '>' . strtotime($last_activity),
            ]);

            if (!empty($orders)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Mark row as abandoned.
     */
    public function mark_as_abandoned($id) {
        global $wpdb;

        $table = self::get_table_name();

        return $wpdb->update(
            $table,
            [
                'abandoned_at' => current_time('mysql'),
            ],
            [
                'id' => absint($id),
            ],
            [
                '%s',
            ],
            [
                '%d',
            ]
        );
    }

    /**
     * Mark row as processed to prevent repeated processing.
     */
    private function mark_as_processed($id) {
        global $wpdb;

        $table = self::get_table_name();

        return $wpdb->update(
            $table,
            [
                'abandoned_at' => current_time('mysql'),
                'recovered'     => 1,
            ],
            [
                'id' => absint($id),
            ],
            [
                '%s',
                '%d',
            ],
            [
                '%d',
            ]
        );
    }

    /**
     * Resolve table name in a safer way.
     */
    private static function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'wc_acart_sms';
    }
}
