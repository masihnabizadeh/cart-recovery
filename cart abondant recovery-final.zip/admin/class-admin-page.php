<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Admin_Page {

    /**
     * Render abandoned carts list page
     */
    public function render_carts_list() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'wc-abandoned-cart-sms'));
        }

        $db = new WC_Acart_SMS_Database();
        $carts = $db->get_abandoned_carts();

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Abandoned Carts', 'wc-abandoned-cart-sms'); ?></h1>

            <?php if (empty($carts)) : ?>
                <p><?php esc_html_e('No abandoned carts found.', 'wc-abandoned-cart-sms'); ?></p>
            <?php else : ?>
                <table class="widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('ID', 'wc-abandoned-cart-sms'); ?></th>
                            <th><?php esc_html_e('Customer', 'wc-abandoned-cart-sms'); ?></th>
                            <th><?php esc_html_e('Phone', 'wc-abandoned-cart-sms'); ?></th>
                            <th><?php esc_html_e('Total', 'wc-abandoned-cart-sms'); ?></th>
                            <th><?php esc_html_e('Status', 'wc-abandoned-cart-sms'); ?></th>
                            <th><?php esc_html_e('Last Activity', 'wc-abandoned-cart-sms'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($carts as $cart) : ?>
                            <tr>
                                <td><?php echo esc_html($cart->id); ?></td>
                                <td><?php echo esc_html($cart->customer_name ?? '-'); ?></td>
                                <td><?php echo esc_html($cart->phone ?? '-'); ?></td>
                                <td><?php echo esc_html(wc_price($cart->cart_total ?? 0)); ?></td>
                                <td><?php echo esc_html($cart->status ?? '-'); ?></td>
                                <td><?php echo esc_html($cart->updated_at ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render settings page
     */
    public function render_settings() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'wc-abandoned-cart-sms'));
        }

        // Save settings
        if (isset($_POST['wc_acart_sms_save_settings'])) {
            check_admin_referer('wc_acart_sms_settings_nonce');

            update_option('wc_acart_sms_coupon_prefix', sanitize_text_field($_POST['coupon_prefix'] ?? 'ACART'));
            update_option('wc_acart_sms_coupon_discount', sanitize_text_field($_POST['coupon_discount'] ?? '10'));
            update_option('wc_acart_sms_coupon_type', sanitize_text_field($_POST['coupon_type'] ?? 'percent'));
            update_option('wc_acart_sms_coupon_expiry', absint($_POST['coupon_expiry'] ?? 7));
            update_option('wc_acart_sms_coupon_length', absint($_POST['coupon_length'] ?? 8));

            update_option('wc_acart_sms_api_key', sanitize_text_field($_POST['api_key'] ?? ''));
            update_option('wc_acart_sms_line_number', sanitize_text_field($_POST['line_number'] ?? ''));

            echo '<div class="notice notice-success"><p>' . esc_html__('Settings saved.', 'wc-abandoned-cart-sms') . '</p></div>';
        }

        $coupon_prefix   = get_option('wc_acart_sms_coupon_prefix', 'ACART');
        $coupon_discount = get_option('wc_acart_sms_coupon_discount', '10');
        $coupon_type     = get_option('wc_acart_sms_coupon_type', 'percent');
        $coupon_expiry   = get_option('wc_acart_sms_coupon_expiry', 7);
        $coupon_length   = get_option('wc_acart_sms_coupon_length', 8);

        $api_key         = get_option('wc_acart_sms_api_key', '');
        $line_number     = get_option('wc_acart_sms_line_number', '');
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Abandoned Cart SMS Settings', 'wc-abandoned-cart-sms'); ?></h1>

            <form method="post">
                <?php wp_nonce_field('wc_acart_sms_settings_nonce'); ?>

                <h2><?php esc_html_e('Coupon Settings', 'wc-abandoned-cart-sms'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="coupon_prefix"><?php esc_html_e('Prefix', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="coupon_prefix" id="coupon_prefix" type="text" class="regular-text" value="<?php echo esc_attr($coupon_prefix); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="coupon_discount"><?php esc_html_e('Discount Value', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="coupon_discount" id="coupon_discount" type="text" class="regular-text" value="<?php echo esc_attr($coupon_discount); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="coupon_type"><?php esc_html_e('Discount Type', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td>
                            <select name="coupon_type" id="coupon_type">
                                <option value="percent" <?php selected($coupon_type, 'percent'); ?>><?php esc_html_e('Percentage', 'wc-abandoned-cart-sms'); ?></option>
                                <option value="fixed_cart" <?php selected($coupon_type, 'fixed_cart'); ?>><?php esc_html_e('Fixed Amount', 'wc-abandoned-cart-sms'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="coupon_expiry"><?php esc_html_e('Validity Period (days)', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="coupon_expiry" id="coupon_expiry" type="number" min="1" value="<?php echo esc_attr($coupon_expiry); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="coupon_length"><?php esc_html_e('Code Length', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="coupon_length" id="coupon_length" type="number" min="4" value="<?php echo esc_attr($coupon_length); ?>"></td>
                    </tr>
                </table>

                <h2><?php esc_html_e('SMS Settings', 'wc-abandoned-cart-sms'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="api_key"><?php esc_html_e('API Key', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="api_key" id="api_key" type="text" class="regular-text" value="<?php echo esc_attr($api_key); ?>"></td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="line_number"><?php esc_html_e('Line Number', 'wc-abandoned-cart-sms'); ?></label></th>
                        <td><input name="line_number" id="line_number" type="text" class="regular-text" value="<?php echo esc_attr($line_number); ?>"></td>
                    </tr>
                </table>

                <p class="submit">
                    <button type="submit" name="wc_acart_sms_save_settings" class="button button-primary">
                        <?php esc_html_e('Save Settings', 'wc-abandoned-cart-sms'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }

    /**
     * Render simple report page
     */
    public function render_reports() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'wc-abandoned-cart-sms'));
        }

        $db = new WC_Acart_SMS_Database();

        $abandoned_count = $db->count_abandoned_carts();
        $sms_sent        = $db->count_sms_sent();
        $recovered_count = $db->count_recovered_carts();
        $recovered_rev   = $db->sum_recovered_revenue();

        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Simple Report', 'wc-abandoned-cart-sms'); ?></h1>

            <table class="widefat striped">
                <tbody>
                    <tr>
                        <th><?php esc_html_e('Abandoned Carts Count', 'wc-abandoned-cart-sms'); ?></th>
                        <td><?php echo esc_html($abandoned_count); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('SMS Sent', 'wc-abandoned-cart-sms'); ?></th>
                        <td><?php echo esc_html($sms_sent); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Recovered Carts', 'wc-abandoned-cart-sms'); ?></th>
                        <td><?php echo esc_html($recovered_count); ?></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Recovered Revenue', 'wc-abandoned-cart-sms'); ?></th>
                        <td><?php echo esc_html(wc_price($recovered_rev)); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        <?php
    }
}
