<?php
if (!defined('ABSPATH')) exit;

class WC_Acart_SMS_Admin_Menu {

    public function __construct() {
        add_action('admin_menu', [$this, 'register_menu']);
    }

    public function register_menu() {
        // ایجاد منوی اصلی اختصاصی در سایدبار
        add_menu_page(
            'بازیابی سبد خرید',           // عنوان صفحه
            'بازیابی سبد SMS',           // عنوان منو
            'manage_woocommerce',        // دسترسی
            'wc-acart-sms',              // اسلاگ اصلی
            [$this, 'render_main_page'], // تابع رندر
            'dashicons-cart',            // آیکون (سبد خرید)
            56                           // موقعیت در منو (بعد از ووکامرس)
        );

        // زیرمنوی اول (تکرار منوی اصلی برای نمایش لیست)
        add_submenu_page(
            'wc-acart-sms',
            'سبدهای رها شده',
            'لیست سبدها',
            'manage_woocommerce',
            'wc-acart-sms',
            [$this, 'render_main_page']
        );

        // زیرمنوی تنظیمات
        add_submenu_page(
            'wc-acart-sms',
            'تنظیمات پیامک و کوپن',
            'تنظیمات',
            'manage_woocommerce',
            'wc-acart-sms-settings',
            [$this, 'render_settings_page']
        );

        // زیرمنوی گزارشات
        add_submenu_page(
            'wc-acart-sms',
            'گزارشات بازیابی',
            'گزارشات',
            'manage_woocommerce',
            'wc-acart-sms-reports',
            [$this, 'render_reports_page']
        );
    }

    public function render_main_page() {
        $admin_page = new WC_Acart_SMS_Admin_Page();
        $admin_page->render_carts_list();
    }

    public function render_settings_page() {
        $admin_page = new WC_Acart_SMS_Admin_Page();
        $admin_page->render_settings();
    }

    public function render_reports_page() {
        $admin_page = new WC_Acart_SMS_Admin_Page();
        $admin_page->render_reports();
    }
}
