<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Cron {

    const CRON_HOOK = 'wc_acart_sms_cron_hook';

    public function __construct() {
        add_action('init', [$this, 'schedule_cron']);
        add_action(self::CRON_HOOK, [$this, 'run_cron']);
    }

    /**
     * زمان‌بندی کرون هر 5 دقیقه
     */
    public function schedule_cron() {
        if (!wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time(), 'five_minutes', self::CRON_HOOK);
        }

        add_filter('cron_schedules', [$this, 'add_custom_schedule']);
    }

    /**
     * افزودن interval سفارشی 5 دقیقه
     */
    public function add_custom_schedule($schedules) {
        if (!isset($schedules['five_minutes'])) {
            $schedules['five_minutes'] = [
                'interval' => 5 * 60,
                'display'  => __('Every 5 Minutes', 'wc-abandoned-cart-sms'),
            ];
        }

        return $schedules;
    }

    /**
     * اجرای فرایندهای اصلی:
     * 1. پیدا کردن سبدهای رها شده
     * 2. ساخت کوپن
     * 3. ارسال پیامک
     */
    public function run_cron() {
        $detector = new WC_Acart_SMS_Abandon_Detector();
        $coupon   = new WC_Acart_SMS_Coupon();
        $sms      = new WC_Acart_SMS_Sms();
        $recovery = new WC_Acart_SMS_Recovery();

        $carts = $detector->get_candidates();

        if (empty($carts)) {
            return;
        }

        foreach ($carts as $cart_row) {
            // علامت‌گذاری به عنوان abandoned
            $detector->mark_as_abandoned($cart_row->id);

            // ساخت کوپن
            $coupon_code = $coupon->create_for_cart($cart_row->id);

            // ساخت لینک بازیابی
            $recovery_link = $recovery->generate_link($cart_row->id);

            // اگر شماره موبایل وجود داشته باشد، پیامک ارسال شود
            if (!empty($cart_row->phone) && !empty($coupon_code)) {
                $template_id = get_option('wc_acart_sms_template_id');

                $params = [
                    'coupon' => $coupon_code,
                    'link'   => $recovery_link,
                ];

                $result = $sms->send_pattern($cart_row->phone, $template_id, $params);

                if ($result && isset($result['messageId'])) {
                    $sms->log_sms_sent($cart_row->id, $result['messageId']);
                }
            }
        }
    }
}
