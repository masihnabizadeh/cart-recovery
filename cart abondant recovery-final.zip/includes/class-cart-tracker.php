<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Cart_Tracker {

    public function __construct() {
        // هوک شدن به تغییرات سبد خرید ووکامرس
        add_action('woocommerce_cart_updated', [$this, 'track_cart']);
    }

    /**
     * ردیابی سبد خرید و ذخیره در دیتابیس
     */
    public function track_cart() {
        if (!function_exists('WC') || is_null(WC()->cart)) {
            return;
        }

        $cart = WC()->cart;

        // اگر سبد خالی بود، نیازی به ردیابی نیست (یا می‌توان رکورد را حذف کرد)
        if ($cart->is_empty()) {
            return;
        }

        global $wpdb;
        $table = WC_Acart_SMS_Database::$table;

        $user_id = get_current_user_id();
        $session_id = $this->get_session_id();
        $phone = $this->get_phone_number($user_id);
        
        $cart_data = json_encode($cart->get_cart());
        $cart_total = $cart->get_total('edit'); // مبلغ خالص بدون فرمت‌دهی

        // بررسی وجود رکورد برای این جلسه یا کاربر
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id, recovered FROM $table WHERE session_id = %s OR (user_id > 0 AND user_id = %d) ORDER BY id DESC LIMIT 1",
            $session_id, $user_id
        ));

        // اگر سبد قبلاً بازیابی شده، دیگر ردیابی‌اش نمی‌کنیم تا چرخه تکرار نشود (مگر با منطق جدید)
        if ($existing && $existing->recovered) {
            return;
        }

        $data = [
            'session_id'    => $session_id,
            'user_id'       => $user_id,
            'phone'         => $phone,
            'cart_data'     => $cart_data,
            'cart_total'    => $cart_total,
            'last_activity' => current_time('mysql'),
        ];

        if ($existing) {
            // آپدیت رکورد فعلی
            $wpdb->update($table, $data, ['id' => $existing->id]);
        } else {
            // ساخت رکورد جدید
            $data['created_at'] = current_time('mysql');
            $data['sms_sent']   = 0;
            $data['recovered']  = 0;
            $wpdb->insert($table, $data);
        }
    }

    /**
     * استخراج شماره موبایل بر اساس اولویت مشخص شده در سند
     */
    private function get_phone_number($user_id) {
        $phone = '';

        // ۱. اولویت اول: Digits (اگر کاربر لاگین باشد یا در سشن ذخیره شده باشد)
        if ($user_id) {
            $phone = get_user_meta($user_id, 'digits_phone', true);
        }

        // ۲. اولویت دوم: WooCommerce billing_phone
        if (empty($phone)) {
            if ($user_id) {
                $phone = get_user_meta($user_id, 'billing_phone', true);
            } else {
                // برای کاربران مهمان، چک کردن اطلاعات سشن یا POST
                $phone = WC()->customer->get_billing_phone();
            }
        }

        return $this->sanitize_iran_phone($phone);
    }

    /**
     * استانداردسازی شماره موبایل برای ایران
     */
    private function sanitize_iran_phone($phone) {
        if (empty($phone)) return '';
        
        // حذف کاراکترهای اضافه
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // تبدیل فرمت 98 به 0
        if (strpos($phone, '98') === 0) {
            $phone = '0' . substr($phone, 2);
        }
        
        // اگر با 9 شروع می‌شود، یک 0 اضافه کن
        if (strpos($phone, '9') === 0 && strlen($phone) == 10) {
            $phone = '0' . $phone;
        }

        return $phone;
    }

    /**
     * دریافت Session ID منحصر به فرد ووکامرس
     */
    private function get_session_id() {
        if (!WC()->session || !WC()->session->has_session()) {
            WC()->session->set_customer_session_cookie(true);
        }
        return WC()->session->get_customer_id();
    }
}
