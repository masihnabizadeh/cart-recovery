<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Database {

    private $table_carts;
    private $table_history;

    public function __construct() {
        global $wpdb;
        $this->table_carts   = $wpdb->prefix . 'wc_acart_sms_carts';
        $this->table_history = $wpdb->prefix . 'wc_acart_sms_history';
    }

    /**
     * متد قبلی برای ساخت جداول (بدون تغییر)
     */
    public function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_carts} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            cart_key varchar(32) NOT NULL,
            customer_id bigint(20) DEFAULT NULL,
            phone varchar(20) DEFAULT NULL,
            cart_total decimal(10,2) DEFAULT 0,
            status varchar(20) DEFAULT 'active',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY cart_key (cart_key)
        ) $charset_collate;

        CREATE TABLE IF NOT EXISTS {$this->table_history} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            cart_id bigint(20) NOT NULL,
            message_id varchar(50) DEFAULT NULL,
            sent_at datetime DEFAULT CURRENT_TIMESTAMP,
            status varchar(20) DEFAULT 'sent',
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * دریافت لیست سبدهای رها شده برای نمایش در جدول مدیریت
     */
    public function get_abandoned_carts($limit = 20, $offset = 0) {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->table_carts} WHERE status = 'abandoned' ORDER BY updated_at DESC LIMIT %d OFFSET %d",
                $limit,
                $offset
            )
        );
    }

    /**
     * گزارش: تعداد کل سبدهای رها شده
     */
    public function count_abandoned_carts() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_carts} WHERE status = 'abandoned'");
    }

    /**
     * گزارش: تعداد پیامک‌های ارسال شده
     */
    public function count_sms_sent() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_history}");
    }

    /**
     * گزارش: تعداد سبدهای بازیابی شده (تبدیل شده به سفارش)
     */
    public function count_recovered_carts() {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_carts} WHERE status = 'recovered'");
    }

    /**
     * گزارش: مجموع درآمد بازیابی شده
     */
    public function sum_recovered_revenue() {
        global $wpdb;
        return (float) $wpdb->get_var("SELECT SUM(cart_total) FROM {$this->table_carts} WHERE status = 'recovered'");
    }
}
