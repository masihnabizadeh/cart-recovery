<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Recovery {

    public function __construct() {
        // گوش دادن به درخواست‌های بازیابی سبد خرید
        add_action('init', [$this, 'handle_recovery_request']);
    }

    /**
     * تولید یک لینک منحصر به فرد برای بازیابی سبد خرید
     */
    public function generate_link($cart_id) {
        $hash = wp_hash($cart_id . AUTH_SALT);
        
        // ذخیره هش در دیتابیس برای تایید در آینده
        global $wpdb;
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            ['recovery_hash' => $hash],
            ['id' => $cart_id]
        );

        return add_query_arg([
            'wcar_id'   => $cart_id,
            'wcar_hash' => $hash
        ], home_url('/'));
    }

    /**
     * پردازش کلیک روی لینک بازیابی
     */
    public function handle_recovery_request() {
        if (!isset($_GET['wcar_id']) || !isset($_GET['wcar_hash'])) {
            return;
        }

        $cart_id = intval($_GET['wcar_id']);
        $hash    = sanitize_text_field($_GET['wcar_hash']);

        global $wpdb;
        $table = WC_Acart_SMS_Database::$table;

        $cart_row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d AND recovery_hash = %s",
            $cart_id,
            $hash
        ));

        if (!$cart_row) {
            wp_die(__('لینک بازیابی معتبر نیست یا منقضی شده است.', 'wc-abandoned-cart-sms'));
        }

        $this->restore_cart($cart_row);
    }

    /**
     * بازسازی سبد خرید و اعمال کوپن
     */
    private function restore_cart($cart_row) {
        if (!function_exists('WC') || is_null(WC()->cart)) {
            return;
        }

        $cart_data = json_decode($cart_row->cart_data, true);
        
        if (empty($cart_data)) {
            return;
        }

        // ۱. خالی کردن سبد فعلی برای جلوگیری از تداخل
        WC()->cart->empty_cart();

        // ۲. اضافه کردن مجدد محصولات
        foreach ($cart_data as $item) {
            $product_id   = $item['product_id'];
            $quantity     = $item['quantity'];
            $variation_id = isset($item['variation_id']) ? $item['variation_id'] : 0;
            $variation    = isset($item['variation']) ? $item['variation'] : [];

            WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation);
        }

        // ۳. اعمال خودکار کوپن (اگر وجود داشته باشد)
        if (!empty($cart_row->coupon_code)) {
            WC()->cart->apply_coupon($cart_row->coupon_code);
        }

        // ۴. آپدیت وضعیت در دیتابیس به عنوان بازیابی شده
        global $wpdb;
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            [
                'recovered'    => 1,
                'recovered_at' => current_time('mysql')
            ],
            ['id' => $cart_row->id]
        );

        // ۵. انتقال کاربر به صفحه تسویه حساب برای تکمیل خرید
        wp_safe_redirect(wc_get_checkout_url());
        exit;
    }
}
