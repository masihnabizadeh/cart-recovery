<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Abandon_Detector {

    /**
     * واکشی سبدهای رها شده که آماده پردازش هستند
     */
    public function get_candidates() {
        global $wpdb;
        $table = WC_Acart_SMS_Database::$table;

        // دریافت زمان انتظار از تنظیمات (پیش‌فرض ۴۵ دقیقه)
        $abandon_time = (int) get_option('wc_acart_sms_abandon_time', 45);
        $threshold_time = date('Y-m-d H:i:s', strtotime("-{$abandon_time} minutes"));

        /**
         * کوئری برای پیدا کردن سبدهایی که:
         * ۱. از زمان آستانه گذشته‌اند (inactivity).
         * ۲. هنوز به عنوان رها شده (abandoned_at) علامت‌گذاری نشده‌اند.
         * ۳. قبلاً بازیابی نشده‌اند.
         */
        $query = $wpdb->prepare(
            "SELECT * FROM $table 
             WHERE last_activity <= %s 
             AND abandoned_at IS NULL 
             AND recovered = 0",
            $threshold_time
        );

        $results = $wpdb->get_results($query);
        $abandoned_carts = [];

        if ($results) {
            foreach ($results as $cart_row) {
                // بررسی نهایی: آیا کاربر بعد از آخرین فعالیت سبد، سفارشی ثبت کرده است؟
                if (!$this->has_recent_order($cart_row)) {
                    $abandoned_carts[] = $cart_row;
                } else {
                    // اگر سفارش ثبت کرده بود، رکورد را حذف یا علامت‌گذاری می‌کنیم که دوباره چک نشود
                    $this->mark_as_processed($cart_row->id);
                }
            }
        }

        return $abandoned_carts;
    }

    /**
     * چک می‌کند که آیا کاربر بعد از آخرین فعالیت سبد، خرید موفقی داشته یا خیر
     */
    private function has_recent_order($cart_row) {
        global $wpdb;

        // اگر کاربر لاگین بود، بر اساس user_id چک می‌کنیم
        if ($cart_row->user_id > 0) {
            $order_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}posts p
                 JOIN {$wpdb->prefix}postmeta pm ON p.ID = pm.post_id
                 WHERE p.post_type = 'shop_order'
                 AND p.post_date >= %s
                 AND pm.meta_key = '_customer_user'
                 AND pm.meta_value = %d",
                $cart_row->last_activity,
                $cart_row->user_id
            ));
            return $order_count > 0;
        }

        // برای کاربران مهمان، بر اساس شماره موبایل در متاهای سفارش چک می‌کنیم
        if (!empty($cart_row->phone)) {
            $order_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}posts p
                 JOIN {$wpdb->prefix}postmeta pm ON p.ID = pm.post_id
                 WHERE p.post_type = 'shop_order'
                 AND p.post_date >= %s
                 AND pm.meta_key = '_billing_phone'
                 AND pm.meta_value = %s",
                $cart_row->last_activity,
                $cart_row->phone
            ));
            return $order_count > 0;
        }

        return false;
    }

    /**
     * علامت‌گذاری سبد به عنوان "رها شده" (پر کردن ستون abandoned_at)
     */
    public function mark_as_abandoned($id) {
        global $wpdb;
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            ['abandoned_at' => current_time('mysql')],
            ['id' => $id]
        );
    }

    /**
     * حذف یا بی اثر کردن رکوردهایی که منجر به خرید شده‌اند
     */
    private function mark_as_processed($id) {
        global $wpdb;
        // قرار دادن یک زمان در abandoned_at اما با وضعیت recovered یا مشابه برای جلوگیری از پردازش مجدد
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            ['abandoned_at' => current_time('mysql'), 'recovered' => 1],
            ['id' => $id]
        );
    }
}
