<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Coupon {

    /**
     * ایجاد یک کوپن اختصاصی برای یک سبد خرید خاص
     * 
     * @param int $cart_id شناسه ردیف در جدول ما
     * @return string|bool کد کوپن ساخته شده یا خطا
     */
    public function create_for_cart($cart_id) {
        // دریافت تنظیمات کوپن از وردپرس (که بعدا در پنل تنظیمات ذخیره میکنیم)
        $type           = get_option('wc_acart_sms_coupon_type', 'percent'); // percent یا fixed_cart
        $amount         = get_option('wc_acart_sms_coupon_amount', '10');
        $prefix         = get_option('wc_acart_sms_coupon_prefix', 'GIFT-');
        $expiry_days    = (int) get_option('wc_acart_sms_coupon_expiry', 7);
        $min_spend      = get_option('wc_acart_sms_coupon_min_spend', '');

        // تولید کد رندوم و یکتا
        $coupon_code = strtoupper($prefix . wp_generate_password(6, false));

        // ایجاد آبجکت کوپن ووکامرس
        $coupon = new WC_Coupon();
        $coupon->set_code($coupon_code);
        $coupon->set_discount_type($type);
        $coupon->set_amount($amount);
        $coupon->set_individual_use(true);
        $coupon->set_usage_limit(1); // فقط یکبار قابل استفاده
        $coupon->set_usage_limit_per_user(1);
        
        // تنظیم حداقل خرید در صورت وجود
        if (!empty($min_spend)) {
            $coupon->set_minimum_amount($min_spend);
        }

        // تنظیم تاریخ انقضا
        if ($expiry_days > 0) {
            $expiry_date = date('Y-m-d', strtotime("+{$expiry_days} days"));
            $coupon->set_date_expires($expiry_date);
        }

        // افزودن متادیتا برای شناسایی کوپن‌های ساخته شده توسط این افزونه
        $coupon->add_meta_data('_is_acart_recovery', 'yes');
        $coupon->add_meta_data('_acart_id', $cart_id);

        // ذخیره نهایی کوپن در دیتابیس ووکامرس
        $saved = $coupon->save();

        if ($saved) {
            // آپدیت کد کوپن در جدول اختصاصی خودمان
            $this->update_cart_record($cart_id, $coupon_code);
            return $coupon_code;
        }

        return false;
    }

    /**
     * ذخیره کد کوپن در رکورد سبد خرید در دیتابیس ما
     */
    private function update_cart_record($cart_id, $code) {
        global $wpdb;
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            ['coupon_code' => $code],
            ['id' => $cart_id]
        );
    }

    /**
     * متد کمکی برای حذف کوپن‌های منقضی شده (اختیاری برای بهینه سازی)
     */
    public function cleanup_expired_coupons() {
        $args = [
            'posts_per_page' => -1,
            'post_type'      => 'shop_coupon',
            'post_status'    => 'publish',
            'meta_query'     => [
                [
                    'key'   => '_is_acart_recovery',
                    'value' => 'yes',
                ]
            ]
        ];

        $coupons = get_posts($args);
        $today = time();

        foreach ($coupons as $post) {
            $coupon = new WC_Coupon($post->ID);
            $expiry = $coupon->get_date_expires();
            
            if ($expiry && $expiry->getTimestamp() < $today) {
                wp_delete_post($post->ID, true);
            }
        }
    }
}
