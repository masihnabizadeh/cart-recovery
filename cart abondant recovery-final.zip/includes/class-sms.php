<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Acart_SMS_Sms {

    private $api_key;
    private $line_number;
    private $api_url = 'https://api.sms.ir/v1/send/verify';

    public function __construct() {
        // دریافت تنظیمات از دیتابیس
        $this->api_key     = get_option('wc_acart_sms_api_key');
        $this->line_number = get_option('wc_acart_sms_line_number');
    }

    /**
     * ارسال پیامک بازیابی با استفاده از الگو
     * 
     * @param string $phone شماره موبایل گیرنده
     * @param string $template_id شناسه الگوی sms.ir
     * @param array $parameters متغیرهای الگو (مثلا کد تخفیف و نام)
     * @return array|bool پاسخ API یا خطا
     */
    public function send_pattern($phone, $template_id, $parameters) {
        if (empty($this->api_key) || empty($phone) || empty($template_id)) {
            return false;
        }

        // آماده‌سازی پارامترها برای فرمت sms.ir
        $formatted_params = [];
        foreach ($parameters as $name => $value) {
            $formatted_params[] = [
                'name'  => (string) $name,
                'value' => (string) $value
            ];
        }

        $body = [
            'mobile'     => $phone,
            'templateId' => (int) $template_id,
            'parameters' => $formatted_params
        ];

        $response = wp_remote_post($this->api_url, [
            'method'      => 'POST',
            'timeout'     => 15,
            'redirection' => 5,
            'httpversion' => '1.0',
            'blocking'    => true,
            'headers'     => [
                'Content-Type' => 'application/json',
                'X-API-KEY'    => $this->api_key,
                'Accept'       => 'text/plain'
            ],
            'body'        => json_encode($body),
            'cookies'     => []
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $result = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($result['status']) && $result['status'] == 1) {
            return $result['data']; // شامل messageId
        }

        return false;
    }

    /**
     * ثبت وضعیت ارسال در جدول دیتابیس ما
     */
    public function log_sms_sent($cart_id, $message_id) {
        global $wpdb;
        $wpdb->update(
            WC_Acart_SMS_Database::$table,
            [
                'sms_sent'       => 1,
                'sms_sent_at'    => current_time('mysql'),
                'sms_message_id' => $message_id
            ],
            ['id' => $cart_id]
        );
    }
}
