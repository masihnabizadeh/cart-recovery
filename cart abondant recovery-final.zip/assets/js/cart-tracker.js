jQuery(document).ready(function($) {
    // پیدا کردن فیلد شماره موبایل در صفحه تسویه حساب ووکامرس
    const phoneField = $('#billing_phone');

    if (phoneField.length) {
        let timeout = null;

        // گوش دادن به رویداد تایپ (با تکنیک Debounce برای فشار نیامدن به سرور)
        phoneField.on('keyup change', function() {
            clearTimeout(timeout);
            const phoneNumber = $(this).val();

            // بررسی حداقل طول شماره (مثلاً برای ایران 11 رقم)
            if (phoneNumber.length >= 10) {
                timeout = setTimeout(function() {
                    $.ajax({
                        url: wc_acart_ajax_obj.ajax_url,
                        type: 'POST',
                        data: {
                            action: 'wc_acart_track_phone',
                            phone: phoneNumber,
                            nonce: wc_acart_ajax_obj.nonce
                        },
                        success: function(response) {
                            console.log('Cart tracked (Phone):', phoneNumber);
                        }
                    });
                }, 1000); // تأخیر 1 ثانیه‌ای بعد از آخرین کلید
            }
        });
    }
});
