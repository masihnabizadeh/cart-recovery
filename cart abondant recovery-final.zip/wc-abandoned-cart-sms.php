<?php
/**
 * Plugin Name: WooCommerce Abandoned Cart SMS (Iran)
 * Description: Detects abandoned carts, generates unique coupons, and sends Persian SMS via sms.ir with recovery links.
 * Version: 1.0.0
 * Author: Masih Nabizadeh
 * Text Domain: wc-abandoned-cart-sms
 */

if (!defined('ABSPATH')) {
    exit;
}

/*
|--------------------------------------------------------------------------
| Constants
|--------------------------------------------------------------------------
*/

define('WC_ACART_SMS_VERSION', '1.0.0');
define('WC_ACART_SMS_PATH', plugin_dir_path(__FILE__));
define('WC_ACART_SMS_URL', plugin_dir_url(__FILE__));
define('WC_ACART_SMS_BASENAME', plugin_basename(__FILE__));

/*
|--------------------------------------------------------------------------
| WooCommerce Dependency Check
|--------------------------------------------------------------------------
*/

add_action('plugins_loaded', function () {

    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="error"><p>';
            echo esc_html__('WooCommerce Abandoned Cart SMS requires WooCommerce to be installed and active.', 'wc-abandoned-cart-sms');
            echo '</p></div>';
        });
        return;
    }

    WC_Acart_SMS::instance();
});

/*
|--------------------------------------------------------------------------
| Main Plugin Class (Singleton Bootstrap)
|--------------------------------------------------------------------------
*/

final class WC_Acart_SMS {

    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->includes();
        $this->init_hooks();
    }

    /*
    |--------------------------------------------------------------------------
    | Include Required Files
    |--------------------------------------------------------------------------
    */

    private function includes() {

        // Core
        require_once WC_ACART_SMS_PATH . 'includes/class-database.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-cart-tracker.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-abandon-detector.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-coupon.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-sms.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-recovery.php';
        require_once WC_ACART_SMS_PATH . 'includes/class-cron.php';

        // Admin
        if (is_admin()) {
            require_once WC_ACART_SMS_PATH . 'admin/class-admin-menu.php';
            require_once WC_ACART_SMS_PATH . 'admin/class-admin-page.php';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Hooks
    |--------------------------------------------------------------------------
    */

    private function init_hooks() {

        register_activation_hook(__FILE__, ['WC_Acart_SMS_Database', 'activate']);
        // توجه: متد deactivate باید در کلاس Cron تعریف شده باشد
        register_deactivation_hook(__FILE__, ['WC_Acart_SMS_Cron', 'deactivate']);

        add_action('init', [$this, 'init_modules']);

        // لود کردن استایل‌ها و اسکریپت‌ها
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

        // هندلرهای AJAX برای ردیابی زنده شماره موبایل
        add_action('wp_ajax_wc_acart_track_phone', [$this, 'handle_phone_tracking']);
        add_action('wp_ajax_nopriv_wc_acart_track_phone', [$this, 'handle_phone_tracking']);
    }

    /*
    |--------------------------------------------------------------------------
    | Initialize Modules
    |--------------------------------------------------------------------------
    */

    public function init_modules() {

        // Database ready
        $db = new WC_Acart_SMS_Database();
        // اگر متد init استاتیک نیست، به این صورت فراخوانی می‌شود
        // در غیر این صورت از WC_Acart_SMS_Database::init() استفاده کنید

        // Core systems
        new WC_Acart_SMS_Cart_Tracker();
        new WC_Acart_SMS_Recovery();

        // Cron system
        new WC_Acart_SMS_Cron();

        if (is_admin()) {
            new WC_Acart_SMS_Admin_Menu();
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Assets & AJAX Handlers
    |--------------------------------------------------------------------------
    */

    public function enqueue_frontend_assets() {
        if (is_checkout()) {
            wp_enqueue_script('wc-acart-tracker-js', WC_ACART_SMS_URL . 'assets/js/cart-tracker.js', ['jquery'], WC_ACART_SMS_VERSION, true);
            
            wp_localize_script('wc-acart-tracker-js', 'wc_acart_ajax_obj', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('wc-acart-track-nonce')
            ]);
        }
    }

    public function enqueue_admin_assets($hook) {
        // فقط در صفحات مربوط به افزونه لود شود
        if (strpos($hook, 'wc-acart-sms') !== false) {
            wp_enqueue_style('wc-acart-admin-css', WC_ACART_SMS_URL . 'assets/css/admin-style.css', [], WC_ACART_SMS_VERSION);
        }
    }

    /**
     * پردازش شماره موبایل ارسالی از سمت کلاینت (AJAX)
     */
    public function handle_phone_tracking() {
        check_ajax_referer('wc-acart-track-nonce', 'nonce');

        $phone = isset($_POST['phone']) ? sanitize_text_field($_POST['phone']) : '';
        
        if (!empty($phone)) {
            $tracker = new WC_Acart_SMS_Cart_Tracker();
            // متدی در کلاس تراکر برای ذخیره آنی شماره
            $tracker->update_cart_phone($phone);
            wp_send_json_success(['message' => 'Phone tracked.']);
        }

        wp_send_json_error(['message' => 'Invalid phone.']);
    }
}
